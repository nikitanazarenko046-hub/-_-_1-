from flask import Flask, request, redirect, render_template, session, send_file, abort
import sqlite3
import uuid

app = Flask(__name__)
app.secret_key = 'super-secret-key'

def db():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as conn:
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE, password TEXT)")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT,
                description TEXT,
                location TEXT,
                speaker TEXT,
                starts_at TEXT,
                capacity INTEGER,
                created_by INTEGER
            )
        """)
        cursor.execute("CREATE TABLE IF NOT EXISTS registrations (id INTEGER PRIMARY KEY AUTOINCREMENT, event_id INTEGER, name TEXT, email TEXT, cancel_token TEXT UNIQUE, created_at TEXT, cancelled_at TEXT)")

        cursor.execute("SELECT count(*) FROM users")
        if cursor.fetchone()[0] == 0:
            cursor.execute("INSERT INTO users (email, password) VALUES (?, ?)", ('admin@example.com', 'admin123'))
            cursor.execute(
                "INSERT INTO events (title, description, location, speaker, starts_at, capacity, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)",
                ('Demo Meetup', 'Тестовое мероприятие', 'Москва, ул. Пример, 1', 'Иван Иванов', '2026-12-01 18:00:00', 3, 1)
            )
            conn.commit()

init_db()

# ---------- Служебное ----------

@app.route('/style.css')
def serve_css():
    return send_file('style.css', mimetype='text/css')

@app.errorhandler(404)
def not_found(e):
    return render_template('404.html'), 404

# ---------- Публичная часть ----------

@app.route('/')
def home():
    conn = db()
    cur = conn.cursor()
    cur.execute("""
        SELECT e.id, e.title, e.description, e.starts_at,
               e.capacity - COUNT(r.id) AS free_seats
        FROM events e
        LEFT JOIN registrations r ON r.event_id = e.id AND r.cancelled_at IS NULL
        GROUP BY e.id
        ORDER BY e.starts_at
    """)
    events = cur.fetchall()
    conn.close()
    return render_template('index.html', events=events)

@app.route('/event/<int:id>')
def event_detail(id):
    conn = db()
    cur = conn.cursor()
    cur.execute("""
        SELECT e.*, e.capacity - COUNT(r.id) AS free_seats
        FROM events e
        LEFT JOIN registrations r ON r.event_id = e.id AND r.cancelled_at IS NULL
        WHERE e.id = ?
        GROUP BY e.id
    """, (id,))
    ev = cur.fetchone()
    conn.close()
    if not ev:
        abort(404)
    return render_template('event.html', ev=ev)

@app.route('/register/<int:id>', methods=['GET', 'POST'])
def register(id):
    conn = db()
    cur = conn.cursor()

    cur.execute("SELECT id, title, capacity FROM events WHERE id = ?", (id,))
    ev = cur.fetchone()
    if not ev:
        conn.close()
        abort(404)

    error, name, email = "", "", ""

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()

        if not email or '@' not in email:
            error = "Введите корректный email"
        else:
            token = uuid.uuid4().hex
            # Атомарная вставка: только если есть свободное место
            cur.execute("""
                INSERT INTO registrations (event_id, name, email, cancel_token, created_at)
                SELECT ?, ?, ?, ?, datetime('now')
                WHERE (
                    SELECT COUNT(*) FROM registrations
                    WHERE event_id = ? AND cancelled_at IS NULL
                ) < ?
            """, (id, name, email, token, id, ev['capacity']))

            if cur.rowcount == 0:
                conn.rollback()
                conn.close()
                return render_template(
                    'index.html', events=[], form_event=ev,
                    error="Извините, места только что закончились",
                    name=name, email=email
                ), 400

            conn.commit()
            conn.close()
            return render_template('index.html', events=[], success_msg="Вы записаны!", cancel_token=token)

    conn.close()
    return render_template('index.html', events=[], form_event=ev, error=error, name=name, email=email)

@app.route('/cancel/<token>', methods=['GET', 'POST'])
def cancel(token):
    if request.method == 'POST':
        conn = db()
        cur = conn.cursor()
        cur.execute("UPDATE registrations SET cancelled_at = datetime('now') WHERE cancel_token = ? AND cancelled_at IS NULL", (token,))
        conn.commit()
        conn.close()
        return render_template('index.html', events=[], success_msg="Запись отменена, место освобождено")
    return render_template('cancel.html', token=token)

# ---------- Аутентификация ----------

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = ""
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password', '')
        conn = db()
        cur = conn.cursor()
        cur.execute("SELECT id FROM users WHERE email = ? AND password = ?", (email, password))
        user = cur.fetchone()
        conn.close()
        if user:
            session['user_id'] = user['id']
            return redirect('/admin')
        error = "Неверный логин или пароль"
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

# ---------- Админка ----------

@app.route('/admin', methods=['GET', 'POST'])
def admin():
    if 'user_id' not in session:
        return redirect('/login')
    conn = db()
    cur = conn.cursor()
    msg = ""

    if request.method == 'POST' and 'add_event' in request.form:
        title = request.form.get('title')
        desc = request.form.get('description')
        location = request.form.get('location')
        speaker = request.form.get('speaker')
        starts = request.form.get('starts_at')
        cap = int(request.form.get('capacity'))
        cur.execute(
            "INSERT INTO events (title, description, location, speaker, starts_at, capacity, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (title, desc, location, speaker, starts, cap, session['user_id'])
        )
        conn.commit()
        msg = "Мероприятие создано!"

    cur.execute("SELECT id, title FROM events ORDER BY starts_at")
    events = cur.fetchall()
    conn.close()
    return render_template('admin.html', events=events, msg=msg)

@app.route('/admin/participants/<int:id>')
def participants(id):
    if 'user_id' not in session:
        return redirect('/login')
    conn = db()
    cur = conn.cursor()
    cur.execute("SELECT name, email, created_at FROM registrations WHERE event_id = ? AND cancelled_at IS NULL", (id,))
    rows = cur.fetchall()
    conn.close()
    return render_template('admin.html', rows=rows, show_participants=True)

@app.route('/admin/edit/<int:id>', methods=['GET', 'POST'])
def edit_event(id):
    if 'user_id' not in session:
        return redirect('/login')
    conn = db()
    cur = conn.cursor()

    cur.execute("SELECT * FROM events WHERE id = ?", (id,))
    ev = cur.fetchone()
    if not ev:
        conn.close()
        abort(404)

    if request.method == 'POST':
        title = request.form.get('title')
        desc = request.form.get('description')
        location = request.form.get('location')
        speaker = request.form.get('speaker')
        starts = request.form.get('starts_at')
        cap = int(request.form.get('capacity'))
        cur.execute("""
            UPDATE events
            SET title = ?, description = ?, location = ?, speaker = ?, starts_at = ?, capacity = ?
            WHERE id = ?
        """, (title, desc, location, speaker, starts, cap, id))
        conn.commit()
        conn.close()
        return redirect('/admin')

    conn.close()
    return render_template('edit_event.html', ev=ev)

@app.route('/admin/delete/<int:id>', methods=['POST'])
def delete_event(id):
    if 'user_id' not in session:
        return redirect('/login')
    conn = db()
    cur = conn.cursor()
    cur.execute("DELETE FROM registrations WHERE event_id = ?", (id,))
    cur.execute("DELETE FROM events WHERE id = ?", (id,))
    conn.commit()
    conn.close()
    return redirect('/admin')

if __name__ == '__main__':
    app.run(debug=True, port=5000)